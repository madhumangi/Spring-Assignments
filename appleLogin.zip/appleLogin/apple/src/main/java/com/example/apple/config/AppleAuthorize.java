package com.example.apple.config;

import com.example.apple.DTOs.SocialUserDTO;
import com.example.apple.model.AppleIDTokenPayload;
import com.example.apple.model.TokenResponse;
import com.example.apple.util.JWTToken;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.databind.ObjectMapper;

import com.google.gson.Gson;

import java.util.Base64;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class AppleAuthorize {
    private static final Logger log = Logger.getLogger(AppleAuthorize.class);
    @Autowired
    private JWTToken jwtToken;
    public void authorizeApple(SocialUserDTO socialUserDTO) throws Exception {
        log.debug("Get Apple User Profile {}", socialUserDTO);
        String appClientId = null;
        if (socialUserDTO.getIdentifierFromApp() != null) {
            // if kid is sent from mobile app
            appClientId = socialUserDTO.getIdentifierFromApp();
        } else {
            // if doing sign in with web using predefined identifier
            appClientId = appleClientId;
        }
//        SocialUserDTO socialUserDTO = new SocialUserDTO();
        // generate personal verification token
        String token = jwtToken.generateJWT(appClientId);

        ////////// Get OAuth Token from Apple by exchanging code
        // Prepare client, you can use other Rest client library also
        OkHttpClient okHttpClient = new OkHttpClient()
                .newBuilder()
                .connectTimeout(70, TimeUnit.SECONDS)
                .writeTimeout(70, TimeUnit.SECONDS)
                .readTimeout(70, TimeUnit.SECONDS)
                .build();
        // Request body for sending parameters as FormUrl Encoded
        RequestBody requestBody = new FormBody
                .Builder()
                .add("client_id", appClientId)
                .add("client_secret", token)
                .add("grant_type", "authorization_code")
                .add("code", socialUserDTO.getAuthorizationCode())
                .build();

        // Prepare rest request
        Request request = new Request
                .Builder()
                .url(APPLE_AUTH_URL)
                .post(requestBody)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .build();

        // Execute api call and get Response
        Response resp = okHttpClient.newCall(request).execute();
        String response = resp.body().string();
        // Parse response as DTO
        ObjectMapper objectMapper = new ObjectMapper();
        TokenResponse tokenResponse = objectMapper.readValue(response, TokenResponse.class);
        // Parse id token from Token
        String idToken = tokenResponse.getId_token();
        String payload = idToken.split("\\.")[1];// 0 is header we ignore it for now
        Base64.Decoder decoder = Base64.getDecoder();
        String decoded = new String(decoder.decode(payload));
        Gson gson=new Gson();
        AppleIDTokenPayload idTokenPayload = gson.fromJson(decoded, AppleIDTokenPayload.class);

        // if we have user obj also from Web or mobile
        // we get only at 1st authorization
        if (socialUserDTO.getUserObj() != null ) {
            JSONObject user = new JSONObject(socialUserDTO.getUserObj());
            JSONObject name = user.has("name") ? user.getJSONObject("name") : null;
            String firstName = name.getString("firstName");
            String lastName = name.getString("lastName");
        }

        // Add your logic here
    }
}
