package com.example.apple.bonus;

import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Optional;

public class SocialRedirect {

    /**
     * Redirect User to Social verify to complete social media authorization
     *
     * @param state the state parameter containing BoxDomain for verification
     * @param code the authorization code
     * @param httpServletResponse the response with redirection for url
     *
     * @throws IOException
     */
    @GetMapping(value = "/social-login/authorize")
    public void forwardSocialAuthorization(@RequestParam String state, @RequestParam Optional<String> code, HttpServletResponse httpServletResponse) throws IOException, IOException {
        String decodedStateParam = URLDecoder.decode(state, "UTF-8");
        JSONObject stateParams = new JSONObject(decodedStateParam);
        // your state param here, i added as just state
        String subDomain = stateParams.getString("subDomain");
        if(code.isPresent()){
            httpServletResponse.sendRedirect(redirectSocialVerifyUrlApple(subDomain, code.get(),null,null));
        }
    }

    /**
     * Url for redirecting user based on subdomain from where authorization is requested
     *
     * @param subDomain the domain of the box
     * @param code the authorization code
     * @return the redirect to verfy social
     */
    String redirectSocialVerifyUrlApple(String subDomain, String code, Optional<String> idToken, Optional<String> user) {
        String redirectUrl = "https://" + subDomain + "/verify-social" + "?code=" + code;
        if (idToken.isPresent()) {
            redirectUrl = redirectUrl + "idToken=" + idToken.get();
        }
        if (user.isPresent()) {
            redirectUrl = redirectUrl + "user=" + user.get();
        }
        return redirectUrl;
    }
}
