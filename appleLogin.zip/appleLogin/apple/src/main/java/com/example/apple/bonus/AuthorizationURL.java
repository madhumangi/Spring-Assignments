package com.example.apple.bonus;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class AuthorizationURL {

//    private static String APPLE_APPLEID_URL = "https://appleid.apple.com";
//    private static String APPLE_AUTH_URL = "https://appleid.apple.com/auth/token";
//    private static String APPLE_PUBLIC_KEY_URL = "https://appleid.apple.com/auth/keys";
    /******
     *To create authorization url for social sign in
     this url will open authentication window for apple sign in
     for a subdomain as state param
     *****/
    public String createAuthorizationUrl(String subDomain) {
        // I have added jsob objct for encodin state paramters like for getting the curent domain used as we have multiple subdomains, you can add your state parameters here
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("subDomain", subDomain);
        try {
            String url = "https://appleid.apple.com/auth/authorize?client_id=" + appleClientId +
                    "&redirect_uri=" + redirectUrl +
                    "&response_type=code%20id_token" +  // to request code and id token both
                    "&scope=" + "name%20email" +  // scopes are name email
                    "&response_mode=" + "form_post" +  // when we request id token only form_post will be available
                    "&state=" + URLEncoder.encode(jsonObject.toString(), "UTF-8");
            return url;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "";
    }
}
