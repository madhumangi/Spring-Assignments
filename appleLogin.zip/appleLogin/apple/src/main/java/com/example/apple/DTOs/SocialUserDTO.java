package com.example.apple.DTOs;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * A DTO for the SocialUser.
 */
@ToString
@Getter
@Setter
public class SocialUserDTO implements Serializable {

    private static final long serialVersionUID = 3484800209656475818L;

    // code varaible returned from sign in request
    private String authorizationCode;


    // If Apple sign in authoriation sends user object as string
    private String userObj;

    // id token from Apple Sign in Authorization if asked
    private String idToken;

    // kid or key identifier from mobile app authorization
    private String identifierFromApp;


}