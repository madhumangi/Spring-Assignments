package com.example.apple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppleApplicationTests {

	@Test
	void contextLoads() {
	}

}
