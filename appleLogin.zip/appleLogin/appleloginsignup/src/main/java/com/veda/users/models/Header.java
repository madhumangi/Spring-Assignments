package com.veda.users.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Header {

    private String kid;
    private String alg;
}
