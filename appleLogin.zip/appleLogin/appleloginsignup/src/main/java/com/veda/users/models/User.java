package com.veda.users.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class User {

    private Name name;
    private String email;



}
