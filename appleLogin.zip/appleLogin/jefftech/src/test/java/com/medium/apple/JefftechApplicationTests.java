package com.medium.apple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JefftechApplicationTests {

	@Test
	void contextLoads() {
	}

}
