package com.medium.apple.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.http.HttpClient;
import java.util.Date;

@RestController
public class Controller {

    private AppleAuth appleAuth;
    private HttpClient httpClient;

    @GetMapping
    private void appleAuth(@RequestParam("authorizationCodeSentByApp") String authorizationCodeSentByApp,@RequestParam("keyIdentifierSentByApp") String keyIdentifierSentByApp) throws Exception {
        var token = appleAuth.generateJWT();

        //Http Requests Client
        var tokenResponse = httpClient.getTokenResponse("CLIENT_ID", token, "authorization_code", authorizationCodeSentByApp);

        var idToken = tokenResponse.getIdToken();

        // Next Steps

        var claims = getClaims(keyIdentifierSentByApp, idToken);

        var iss = claims.get("iss", String.class);
        var aud = claims.get("aud", String.class);
        var exp = claims.get("exp", Date.class);
        var iat = claims.get("iat", Date.class);
        var appleIdentifier = claims.get("sub", String.class);
        var atHash = claims.get("at_hash", String.class);
        var authTime = claims.get("auth_time", Long.class);
        var email = claims.get("email", String.class);
        var emailVerified = claims.get("email_verified", String.class);
        // Do with params what you need to do
    }
}
