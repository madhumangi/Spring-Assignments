package com.medium.apple.rest;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;

import java.io.File;
import java.io.FileReader;
import java.math.BigInteger;
import java.net.http.HttpClient;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.util.Base64;
import java.util.Date;

public class AppleAuth {

    private PrivateKey generatePrivateKey() throws Exception {
        var file = new File("CERTIFICATE_PATH");

        var pemParser = new PEMParser(new FileReader(file));
        var converter = new JcaPEMKeyConverter();
        var object = (PrivateKeyInfo) pemParser.readObject();

        return converter.getPrivateKey(object);
    }

    String generateJWT() throws Exception {
        var pKey = generatePrivateKey();

        return Jwts.builder()
                .setHeaderParam(JwsHeader.KEY_ID, "KEY_ID")
                .setIssuer("TEAM_ID")
                .setAudience("https://appleid.apple.com")
                .setSubject("CLIENT_ID")
                .setExpiration(new Date(System.currentTimeMillis() + (1000 * 60 * 5)))
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .signWith(SignatureAlgorithm.ES256, pKey)
                .compact();
    }



    private PublicKey createPublicKeyApple(String keyIdentifier) throws InvalidKeySpecException, NoSuchAlgorithmException {
        // Http Requests Client
        var applePublicKeysList = httpClient.getListPublicKeys();

        var applePublicKey = applePublicKeysList.getKeys().stream()
                .filter(publicKey -> keyIdentifier.equals(publicKey.getKid()))
                .findFirst();

        if (!applePublicKey.isPresent()) throw new AppleKeysException("Not matching key");

        var modulus = new BigInteger(1, Base64.getUrlDecoder().decode(applePublicKey.get().getN()));
        var exponent = new BigInteger(1, Base64.getUrlDecoder().decode(applePublicKey.get().getE()));

        return KeyFactory.getInstance(applePublicKey.get().getKty()).generatePublic(new RSAPublicKeySpec(modulus, exponent));
    }

    private Claims getClaims(String keyIdentifier, String idToken) throws InvalidKeySpecException, NoSuchAlgorithmException{
        var publicKey = createPublicKeyApple(keyIdentifier);
        try {
            return Jwts.parser().setSigningKey(publicKey).parseClaimsJws(idToken).getBody();
        } catch(Exception e) {
            LOG.info("Exception JWT Signature" + e.getMessage());
            throw new AppleKeysException("Not a right public key");
        }
    }


}
