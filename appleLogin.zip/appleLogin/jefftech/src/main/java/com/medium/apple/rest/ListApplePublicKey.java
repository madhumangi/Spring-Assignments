package com.medium.apple.rest;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.medium.apple.models.ApplePublicKey;

import java.util.List;

public final class ListApplePublicKey {

    private final List<ApplePublicKey> keys;

    public ListApplePublicKey(@JsonProperty("keys") List<ApplePublicKey> keys) {
        this.keys = keys;
    }

    public List<ApplePublicKey> getKeys() {
        return keys;
    }
}